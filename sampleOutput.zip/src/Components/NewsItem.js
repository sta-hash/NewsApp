import React, { Component } from 'react'

export default class NewsItem extends Component {
 
  render() {
    let {title,description,imageUrl,newsUrl,author,date}= this.props;
    return (
      <div>
        <div classname="card" style={{width: "18rem"}}>
   <img src={imageUrl} 
  className="card-img-top"
  alt="..." 
    /> 
  <div classname="card-body">
    <h5 classname="card-title">{title}...</h5>
    <p classname="card-text">{description}...</p>
    
      
    {/* <p class="card-text"><small classname="text-muted">by {!author?"unknown":author} on {date}</small></p> */}
    <a href={newsUrl} classname="btn btn-sm btn-primary">Read more</a>
  </div>
</div>
        
      </div>
    );
  }
}
