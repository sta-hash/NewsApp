import React, { Component } from 'react'
// import PropTypes from 'prop-types'
import Navbar from "./Components/Navbar";
import News from "./Components/News";
import {BrowserRouter,Router,Routes,Route} from "react-router-dom";
export default class App extends Component {
 
  render() {
    return (
    <div>
      <BrowserRouter>
      <Navbar/>
      <Routes>
      <Route path="/" element={<News page size={5} country ="in" category="general"/>}></Route>
      <Route path="business" element={<News page size={5} country ="in" category="business"/>}></Route>
      <Route path="entertainment" element={<News page size={5} country ="in" category="entertainment"/>}></Route>
      <Route path="health" element={<News page size={5} country ="in" category="health"/>}></Route>
      <Route path="scinece" element={<News page size={5} country ="in" category="science"/>}></Route>
      <Route path="sport" element={<News page size={5} country ="in" category="sport"/>}></Route>
      <Route path="technology" element={<News page size={5} country ="in" category="technology"/>}></Route>
      <Route path="/" element={<News page size={5} country ="in" category="general"/>}></Route>
      
      </Routes>
      </BrowserRouter>
      {/* <Navbar/> */}
      {/* <News page size={5} country ="in" category="general"/> */}
      </div>
    );
  }
}
